<template>
    <div class="card">
      <h3>{{ topic.name }}</h3>
      <p>Comments:</p>
      <ul>
        <CommentCard 
            v-for="comment in topic.comments" 
            :key="comment.date"
            :comment="comment"
            :user="user"
            @edit-comment="editComment"
            @delete-comment="deleteComment"
        />

      </ul>
      <button class="btn btn-primary" @click="showAddCommentModal=true">Add Comment</button>
      <AddCommentModal 
        v-if="showAddCommentModal" 
        :user="user" 
        @comment-added="addComment" 
        @close="showAddCommentModal=false"
      />
    </div>
  </template>
  
  <script>
  import CommentCard from './CommentCard.vue';
  import AddCommentModal from './AddCommentModal.vue';
  import { ref } from 'vue';
  
  export default {
    components: {
      CommentCard,
      AddCommentModal
    },
    props: ['topic', 'user'],
    setup(props, { emit }) {
      const showAddCommentModal = ref(false);
  
      function addComment(newComment) {
        props.topic.comments.push(newComment);
        showAddCommentModal.value = false;
      }
  
      function editComment(editedComment) {
        // Logic to edit the comment in the topic.comments array
      }
  
      function deleteComment(commentToDelete) {
        const index = props.topic.comments.findIndex(comment => comment.date === commentToDelete.date);
        if (index !== -1) {
          props.topic.comments.splice(index, 1);
        }
      }
  
      return {
        showAddCommentModal,
        addComment,
        editComment,
        deleteComment
      };
    }
  };
  </script>
  
<template>
    <div>
        <TopicCard 
            v-for="topic in topics" 
            :key="topic.guid"
            :topic="topic"
            :user="user"
        />
    </div>
  </template>
  
  <script>
  import TopicCard from './TopicCard.vue';
  export default {
    components: {
      TopicCard
    },
    props: ['topics', 'user']
  };
  </script>
  
<template>
    <div class="modal">
      <div class="modal-content">
        <h2>Add Comment</h2>
        <textarea v-model="commentText" placeholder="Your comment..."></textarea>
        <button @click="addComment">Add Comment</button>
        <button @click="closeModal">Close</button>
      </div>
    </div>
  </template>
  
  <script>
  import { ref } from 'vue';
  export default {
    props: {
      topic: Object,
      user: Object
    },
    setup(props, { emit }) {
      const commentText = ref('');
  
      function addComment() {
        const comment = {
          comment: commentText.value,
          date: new Date().toISOString(),
          by: props.user.name
        };
        emit('comment-added', comment);
        closeModal();
      }
  
      function closeModal() {
        emit('close');
      }
  
      return {
        commentText,
        addComment,
        closeModal
      };
    }
  };
  </script>
  